# live-camera
网络摄像头-基于HTML5+Canvas+Websocket+[Workerman](http://www.workerman.net)

##  在线示例

提示：最好用火狐测试，谷歌浏览器升级了安全策略，谷歌浏览器只能在https下才能利用html5打开摄像头。

1、摄像头录制页面 http://www.workerman.net/demos/live-camera/camera.html

2、实时接收视频流页面 http://www.workerman.net/demos/live-camera/


##  使用方法(linux 系统)

1、下载 或者 ```git clone https://github.com/walkor/live-camera```

2、运行 ```composer install```

3、运行 php start.php start -d

4、录制摄像的页面为 http://127.0.0.1:8088/camera.html

5、接收视频流的页面为 http://127.0.0.1:8088/

